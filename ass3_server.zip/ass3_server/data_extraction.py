import pandas as pd
import numpy as np
from scipy.stats import pearsonr
import os
import models
here = os.path.dirname(os.path.abspath(__file__))
print("here1: ",here)

def get_pm_happy_all_data():
    pm25 = pd.read_csv("static/potential data/PM2.5/API_EN.ATM.PM25.MC.M3_DS2_en_csv_v2.csv",sep='\t')
    happy2015 = pd.read_csv("static/potential data/world-happiness-report/happy_2015.csv")

    pm25_2015 = pm25[["Country Name","2015"]]
    #pd.merge(pm25_2015,happy2015,on='location')

    pm25_2015 = pm25_2015.rename(columns={"Country Name":"Country","2015":"pm25_2015"})

    combined_data = pd.merge(pm25_2015,happy2015,on='Country')
#    combined_data = combined_data.replace(np.nan, 0)
    combined_data = combined_data.dropna(axis=0, how='any')
    return combined_data

def get_pm_data():
    pm25 = pd.read_csv("static/potential data/PM2.5/API_EN.ATM.PM25.MC.M3_DS2_en_csv_v2.csv",sep='\t')
    pm25_2015 = pm25[["Country Name", "2015"]]
    pm25_2015 = pm25_2015.rename(columns={"Country Name": "Country", "2015": "pm25_2015"})
    return pm25_2015.to_json(orient="records")


def get_happy_data():
    happy2015 = pd.read_csv("static/potential data/world-happiness-report/happy_2015.csv")
    return happy2015.to_json(orient="records")

#join json data
def join_data(col_to_join, data1, data2):
    data1 = pd.read_json(data1,orient="records")
    data2 = pd.read_json(data2, orient="records")
    combined_data = pd.merge(data1, data2, on=col_to_join)
    #drop rows contains null values

    combined_data = combined_data.dropna(axis=0, how='any')
    return combined_data.to_json(orient="records")


def get_pm_happy_data(data, col1 = "pm25_2015",col2 = "Happiness Score"):
    data = pd.read_json(data, orient="records")
    data_fm = data[["Country",col1, col2]]
    data_list = np.array(data_fm).tolist()
    cols = list(data_fm.columns)
    col_list_1 = list(data_fm.iloc[:,1])
    col_list_2 = list(data_fm.iloc[:,2])
    pr, p_value = get_pearson_correlation(col_list_1, col_list_2)
    #get features
    features = list(data.columns)
    print(features)
    features.remove('Country')
    features.remove('Region')
    features.remove('Happiness Rank')
    features.remove('Standard Error')
    data_obj = models.PmHappyAnalytics(data_list,cols,pr, p_value,features)
    return data_obj

#comb_data = get_pm_happy_all_data()
#data_list,cols,col_list_1,col_list_2 = get_pm_happy_data(comb_data)
#p = pearsonr(col_list_1,col_list_2)

def get_pearson_correlation(arr1,arr2):
    pr, p_value = pearsonr(arr1,arr2)
    return pr, p_value
    
#
# print(cols)