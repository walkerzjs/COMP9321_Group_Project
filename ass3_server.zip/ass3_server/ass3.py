from flask import Flask,render_template,request,redirect,jsonify
from flask_restful import reqparse
import data_extraction as de
import os
app = Flask(__name__)
here = os.path.dirname(os.path.abspath(__file__))
print(here)
print("here: {}".format(here))
os.chdir(here)

@app.route('/')
def hello_world():
    combined_data = de.get_pm_happy_all_data()
    # data,cols,pr,p_value = de.get_pm_happy_data(combined_data, col1 = "pm25_2015",col2 = "Health (Life Expectancy)")
    # data, cols,pr,p_value = de.get_pm_happy_data(combined_data, col1="pm25_2015", col2="Happiness Score")
    data,cols,pr,p_value = de.get_pm_happy_data(combined_data, col1 = "Happiness Score",col2 = "Health (Life Expectancy)")
    # data,cols,pr,p_value = de.get_pm_happy_data(combined_data, col1 = "pm25_2015",col2 = "Economy (GDP per Capita)")
    # data,cols,pr,p_value = de.get_pm_happy_data(combined_data, col1 = "pm25_2015",col2 = "Family")
    # data, cols, pr, p_value = de.get_pm_happy_data(combined_data, col1="pm25_2015", col2="Trust (Government Corruption)")

    print(cols)
    return render_template("scatter.html",data = data,cols = cols, pr = pr, p = p_value)


@app.route('/pm',methods=["GET"])
def get_pm_data():
    # print("enter")
    pm_json = de.get_pm_data()
    # print(pm_json)
    return jsonify(pm_json),200


@app.route('/happy',methods=["GET"])
def get_happy_data():
    happy_json = de.get_happy_data()
    return jsonify(happy_json), 200


@app.route('/pm_happy', methods = ["POST"])
def get_pm_happy_data():
    print("enter")
    parser = reqparse.RequestParser()
    parser.add_argument('pm_json', type=str)
    parser.add_argument('happy_json', type=str)
    args = parser.parse_args()
    pm_json = args.get("pm_json")
    happy_json = args.get("happy_json")
    combined_data = de.join_data("Country", pm_json, happy_json)
    # print(combined_data)
    return jsonify(combined_data),200


@app.route('/analyse_pm_happy',methods=["POST"])
def pm_happy_correlation():
    parser = reqparse.RequestParser()
    parser.add_argument('data', type=str)
    parser.add_argument('col1', type=str)
    parser.add_argument('col2', type=str)
    args = parser.parse_args()
    data = args.get("data")
    col1 = args.get("col1")
    col2 = args.get("col2")
    data_obj = de.get_pm_happy_data(data, col1 = col1,col2 = col2)
    print(data_obj.__dict__)
    return jsonify(data_obj.__dict__)


if __name__ == '__main__':
    app.run(debug=True)
