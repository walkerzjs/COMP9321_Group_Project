class PmHappyAnalytics():
    def __init__(self, data_list,cols,pr, p_value,features):
        self.data_list = data_list
        self.cols = cols
        self.pr = pr
        self.p_value = p_value
        self.features = features
