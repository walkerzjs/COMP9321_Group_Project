from flask import Flask,render_template,request,redirect,jsonify
import requests
import os
import json
app = Flask(__name__)
here = os.path.dirname(os.path.abspath(__file__))
print(here)
print("here: {}".format(here))
os.chdir(here)


@app.route('/')
def hello_world():

    # print("hello")
    return "hello"


# @app.route('/retrieve_pm')
def retrive_pm_data():
    # query = request.form['queryRetreive']
    # accept = request.form['checkbox']
    # accept_tp = accept_type(accept)
    # token = ""
    # if "token" in session:
    #     token = session["token"]
    accept_tp='JSON'
    url = "http://127.0.0.1:5000/pm"
    result = requests.get(url, params = None,
                           headers = {
                                      "ACCEPT": accept_tp})
    # print(json.loads(result.text))
    return json.loads(result.text)

# @app.route('/retrieve_happy')
def retrive_happy_data():
    # query = request.form['queryRetreive']
    # accept = request.form['checkbox']
    # accept_tp = accept_type(accept)
    # token = ""
    # if "token" in session:
    #     token = session["token"]
    accept_tp='JSON'
    url = "http://127.0.0.1:5000/happy"
    result = requests.get(url, params = None,
                           headers = {
                                      "ACCEPT": accept_tp})
    # print(json.loads(result.text))
    return json.loads(result.text)




#combine two data sets
@app.route('/retrieve_pm_happy')
def retrieve_pm_happy():

    pm_json = retrive_pm_data()
    happy_json = retrive_happy_data()
    accept_tp='JSON'
    url = "http://127.0.0.1:5000/pm_happy"
    data_json = {"pm_json":pm_json,"happy_json":happy_json}
    result = requests.post(url, json = data_json,
                           headers = {"Content-Type": "application/json"})
    # print(json.loads(result.text))
    return json.loads(result.text)


#draw correlation graph from the combined data set
@app.route('/analyse_pm_happy',methods=['GET','POST'])
def analyse_pm_happy():
    data = retrieve_pm_happy()
    try:

        pm_happy_feature1 = request.form['pm_happy_feature1']
        pm_happy_feature2 = request.form['pm_happy_feature2']
        print('enter_try')
        print(pm_happy_feature1)
        print(pm_happy_feature2)
    except:
        print('enter_except')
        pm_happy_feature1 = "pm25_2015"
        pm_happy_feature2 = "Happiness Score"
    # data_json = {"data":data,"col1":"pm25_2015","col2":"Happiness Score"}
    data_json = {"data": data, "col1": pm_happy_feature1, "col2": pm_happy_feature2}
    url = "http://127.0.0.1:5000/analyse_pm_happy"
    accept_tp = 'JSON'
    result = requests.post(url, json = data_json,
                           headers = {"Content-Type": "application/json","ACCEPT": accept_tp})
    # print(result.content.decode())
    # print(type(result.content.decode()))
    res_str = result.content.decode()
    res_dict =json.loads(res_str)
    print(res_dict)
    print(res_dict.keys())
    return render_template("scatter.html", data = res_dict['data_list'], cols = res_dict['cols'],
                           pr = res_dict['pr'],p = res_dict['p_value'],features = res_dict['features'])



if __name__ == '__main__':
    app.run(debug=True,port=1233)